# Mock Scripts

The files in this folder are mock scripts for TinyPilot development.

## To enable

```bash
sudo ./dev-scripts/enable-mock-scripts
```
